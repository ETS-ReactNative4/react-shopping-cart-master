import React, { Component } from "react";

class Home extends Component {
    render() {
        return (
            <div>
                <h2>This is home</h2>
                <p>Home descriptions go in this spot</p>
            </div>
        );
    }
}

export default Home;